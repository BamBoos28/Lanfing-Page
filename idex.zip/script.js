window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 10 || document.documentElement.scrollTop > 10) {
    document.getElementById("navbar").style.background = "#929EC4";
    document.getElementById("navbar").style.borderBottom = "3px solid white";
    document.getElementById("navbar").style.paddingTop = "2rem";
    document.getElementById("navbar").style.paddingBottom = "2rem";
  } else {
    document.getElementById("navbar").style.background = "";
    document.getElementById("navbar").style.borderBottom = "";
    document.getElementById("navbar").style.paddingTop = "1.5rem";
    document.getElementById("navbar").style.paddingBottom = "1.5rem";
  }
}